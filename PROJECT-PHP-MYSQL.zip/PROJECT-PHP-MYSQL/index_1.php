<?php
require_once 'functions.php';
require_once 'header.php';
?>
<h1>HELLO WORLD</h1>
<div class="row">
    <div class="col-md-4">
        COLONNA1
    </div>
     <div class="col-md-4">
        COLONNA2
    </div>
     <div class="col-md-4">
        COLONNA3
    </div>
</div>
<?php
require_once 'footer.php';

